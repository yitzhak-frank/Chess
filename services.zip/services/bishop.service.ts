import { Injectable } from '@angular/core';
import { ToolClass, ToolInfo } from '../interfaces/tool-interface';
import { chessMatrix } from '../data/tableArrays';
import { firstPosition } from '../data/toolsPosition';

@Injectable({
  providedIn: 'root'
})
export class BishopService implements ToolClass {

  public tool: string;
  public color: boolean;
  public position: string;
  public index: number[];
  public chessMatrix: Array<Array<string>> = chessMatrix;
  public toolsPosition: object = firstPosition;
  public thretsMap: string[];
  public possibleMoves: string[];

  constructor() {}

  private getIndexOfPosition(): void {
    this.chessMatrix.forEach((ar, i)=> ar.forEach((item, x) => (item == this.position)? this.index = [i, x]:''));
  }

  public getToolInfo(): ToolInfo {
    let {tool, color, position} = this
    return {tool, color, position};
  }

  public getPossibleMoves(): string[] {
    this.calcPossibleMoves(this.checkPossibleMoves);
    return this.possibleMoves;
  }

  public getThretsMap(): string[] {
    this.calcPossibleMoves(this.checkThretsMap);
    return this.thretsMap;
  }

  public calcPossibleMoves(check: (currentCell: string) => boolean | void): void {
    this.thretsMap = [];
    this.possibleMoves = [];
    this.getIndexOfPosition();
    for(let i = 1; (i + this.index[0] < 8) && (i + this.index[1] < 8); i++)
      if(check(this.chessMatrix[this.index[0] + i][this.index[1] + i])) break;
    for(let i = 1; (this.index[0] - i >= 0) && (this.index[1] - i >= 0); i++)
      if(check(this.chessMatrix[this.index[0] - i][this.index[1] - i])) break;
    for(let i = 1; (i + this.index[0] < 8) && (this.index[1] - i >= 0); i++)
      if(check(this.chessMatrix[this.index[0] + i][this.index[1] - i])) break;
    for(let i = 1; (this.index[0] - i >= 0) && (i + this.index[1] < 8); i++)
      if(check(this.chessMatrix[this.index[0] - i][this.index[1] + i])) break;
  }

  private checkPossibleMoves(currentCell: string): boolean | void {
    console.log(this.toolsPosition)
    if(!this.toolsPosition[currentCell]) this.possibleMoves.push(currentCell);
    else if(this.toolsPosition[currentCell].color == this.color) return true;
    else {
      this.possibleMoves.push(currentCell);
      return true;
    }
  }

  private checkThretsMap(currentCell: string): boolean | void {
    if(currentCell && !this.toolsPosition[currentCell]) this.thretsMap.push(currentCell);
    else if(currentCell) {
      this.thretsMap.push(currentCell);
      return true;
    }
  }
}
