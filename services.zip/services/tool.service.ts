import { Injectable } from '@angular/core';
import { ToolClass } from '../interfaces/tool-interface';

@Injectable({
  providedIn: 'root'
})
export class ToolService {

  public tool: string = this.ToolClass.tool;
  public color: boolean = this.ToolClass.color;
  public position: string = this.ToolClass.position;

  constructor(public ToolClass: ToolClass) {}
}
