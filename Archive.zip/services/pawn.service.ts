import { Injectable } from '@angular/core';
import { ToolClass, ToolInfo } from '../interfaces/tool-interface';
import { chessMatrix } from '../data/tableArrays';
import { firstPosition } from '../data/toolsPosition';

@Injectable({
  providedIn: 'root'
})
export class PawnService implements ToolClass {

  public tool: string;
  public color: boolean;
  public position: string;
  public index: number[];
  public chessMatrix: Array<Array<string>> = chessMatrix;
  public toolsPosition: object = firstPosition;
  public thretsMap: string[];
  public isVirgin: boolean;
  public possibleMoves: string[];

  constructor() {}

  private getIndexOfPosition(): void {
    this.chessMatrix.forEach((ar, i)=> ar.forEach((item, x) => (item == this.position)? this.index = [i, x]:''));
  }

  public getToolInfo(): ToolInfo {
    let {tool, color, position} = this
    return {tool, color, position};
  }

  public getPossibleMoves(): string[] {
    this.checkToolColor(this.checkPossibleMoves);
    return this.possibleMoves;
  }

  public getThretsMap(): string[] {
    this.checkToolColor(this.checkThretsMap);
    return this.thretsMap;
  }

  checkToolColor(check: (currentCell: string) => void): void {
    this.thretsMap = [];
    this.possibleMoves = [];
    this.getIndexOfPosition();
    if(this.color) this.calcPossibleMoves(1, check);
    else this.calcPossibleMoves(-1, check);
  }

  calcPossibleMoves(direction: number, check: (currentCell: string) => void): void {
    if(this.toolsPosition[this.position].isVirgin)
      check(this.chessMatrix[this.index[0]][this.index[1] + direction + direction]);
    check(this.chessMatrix[this.index[0]][this.index[1] + direction]);
    this.calcToolsToEat(direction, check);
  }

  calcToolsToEat(direction: number, check: (currentCell: string) => void): void {
    if(this.chessMatrix[this.index[0] + (direction * -1)])
      check(this.chessMatrix[this.index[0] + (direction * -1)][this.index[1] + direction]);
    if(this.chessMatrix[this.index[0] + direction])
      check(this.chessMatrix[this.index[0] + direction][this.index[1] + direction]);
  }

  checkPossibleMoves(currentCell: string): void {
    if(!this.toolsPosition[currentCell]) this.possibleMoves.push(currentCell);
  }

  checkToolsToEat(currentCell: string): void {
    if(this.toolsPosition[currentCell] && this.toolsPosition[currentCell].color != this.color) this.possibleMoves.push(currentCell);
  }

  checkThretsMap(currentCell: string) {
    if(this.toolsPosition[currentCell] && this.toolsPosition[currentCell].color != this.color) this.thretsMap.push(currentCell);
  }
}
