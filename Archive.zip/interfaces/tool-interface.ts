export interface ToolInfo {
  color:     boolean;
  tool:       string;
  position?:  string;
  isVirgin?: boolean;
  selected?: boolean;
  comp?:      string;
}

export interface ToolData {
  toolInfo:      ToolInfo,
  possibleMoves: string[]
}

export interface ToolClass {
  tool: string;
  color: boolean;
  index: number[];
  position: string;
  isVirgin?: boolean;
  chessMatrix: Array<Array<string>>;
  toolsPosition: object;
  possibleMoves: string[];
  getToolInfo: () => ToolInfo;
  getThretsMap: () => string[];
  getPossibleMoves: () => string[];
}
