import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { KingService } from 'src/app/services/king.service';
import { KnightService } from 'src/app/services/knight.service';
import { ToolData, ToolInfo } from '../../../interfaces/tool-interface';

@Component({
  selector: 'app-knight',
  template: `<span (click)="moveTool()">{{toolInfo.tool}}</span>`,
  styles: [],
  providers: [KingService]
})
export class KnightComponent implements OnInit {

  @Input() toolInfo: ToolInfo;
  @Output() public toolSelect = new EventEmitter<ToolData>();

  constructor(private KnightClass: KnightService) {}

  setServiceInfo() {
    this.KnightClass.tool     = this.toolInfo.tool;
    this.KnightClass.color    = this.toolInfo.color;
    this.KnightClass.position = this.toolInfo.position;
  }

  moveTool() {
    let possibleMoves = this.KnightClass.getPossibleMoves();
    this.toolSelect.emit({possibleMoves, toolInfo: this.toolInfo})
  }

  ngOnInit(): void {
    this.setServiceInfo();
  }

}
