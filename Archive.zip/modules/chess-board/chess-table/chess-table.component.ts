import { Component, OnInit } from '@angular/core';
import { CalcToolsThrets } from 'src/app/thretsCalc';
import { chessMatrix, cols, rows } from '../../../data/tableArrays';
import { firstPosition } from '../../../data/toolsPosition';
import { ToolData, ToolInfo } from '../../../interfaces/tool-interface';

@Component({
  selector: 'app-chess-table',
  templateUrl: './chess-table.component.html',
  styleUrls: ['./chess-table.component.scss']
})
export class ChessTableComponent implements OnInit {

  rows: number[] = rows;
  cols: string[] = cols;
  chessMatrix: Array<Array<string>> = chessMatrix;
  toolsPosition: object = firstPosition;
  colorTurn: boolean = true;
  slectedTool: ToolInfo;
  possibleMoves: string[] = [];
  thretsTest = [];

  constructor() {}

  emptyCellOnClick(e): void {
    if(this.slectedTool) this.moveTool(e.target.id);
  }

  toolsOnClick({toolInfo, possibleMoves}: ToolData): void {
    if(toolInfo.color != this.colorTurn && !this.slectedTool) return;
    if(this.slectedTool && this.slectedTool.color != toolInfo.color) this.moveTool(toolInfo.position);
    else {
      if(this.slectedTool) this.toolsPosition[this.slectedTool.position].selected = false;
      if(possibleMoves.length) this.toolsPosition[toolInfo.position].selected = true;
      this.slectedTool = toolInfo;
    }
    if(this.slectedTool) this.possibleMoves = possibleMoves;
  }

  private moveTool(position: string): void {
    if(!this.possibleMoves.includes(position)) {
      this.possibleMoves = [];
      this.toolsPosition[this.slectedTool.position].selected = false;
      delete this.slectedTool;
      return;
    }
    this.possibleMoves = [];
    this.toolsPosition[this.slectedTool.position].isVirgin = false;
    this.colorTurn = !this.colorTurn;
    this.toolsPosition[position] = this.slectedTool;
    delete this.toolsPosition[this.slectedTool.position];
    delete this.slectedTool;
    this.checkIsChess();
  }

  private checkIsChess() {
    let calcChessThrets = new CalcToolsThrets();
    let thretsMap = calcChessThrets.createThretsMap();
    this.thretsTest = thretsMap[1]
    for(let i in this.toolsPosition) {
      if(this.toolsPosition[i].comp == 'king') {
        if(this.toolsPosition[i].color) {
          if(thretsMap[0].includes(this.toolsPosition[i].position)) this.toolsPosition[i].isChess = true;
          else this.toolsPosition[i].isChess = false;
        } else {
          if(thretsMap[1].includes(this.toolsPosition[i].position)) this.toolsPosition[i].isChess = true;
          else this.toolsPosition[i].isChess = false;
        }
      }
    }
  }

  ngOnInit(): void {}
}
