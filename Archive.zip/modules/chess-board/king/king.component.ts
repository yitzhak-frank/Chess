import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { KingService } from 'src/app/services/king.service';
import { KnightService } from 'src/app/services/knight.service';
import { ToolData, ToolInfo } from '../../../interfaces/tool-interface';

@Component({
  selector: 'app-king',
  template: `<span (click)="moveTool()">{{toolInfo.tool}}</span>`,
  styles: [],
  providers: [KnightService]
})
export class KingComponent implements OnInit {

  @Input() toolInfo: ToolInfo;
  @Output() public toolSelect = new EventEmitter<ToolData>();

  constructor(private KingClass: KingService) {}

  setServiceInfo() {
    this.KingClass.tool     = this.toolInfo.tool;
    this.KingClass.color    = this.toolInfo.color;
    this.KingClass.position = this.toolInfo.position;
  }

  moveTool() {
    let possibleMoves = this.KingClass.getPossibleMoves();
    this.toolSelect.emit({possibleMoves, toolInfo: this.toolInfo})
  }

  ngOnInit(): void {
    this.setServiceInfo();
  }

}
