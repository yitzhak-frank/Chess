import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { BishopService } from 'src/app/services/bishop.service';
import { ToolData, ToolInfo } from '../../../interfaces/tool-interface';

@Component({
  selector: 'app-bishop',
  template: `<span (click)="moveTool()">{{toolInfo.tool}}</span>`,
  styles: [],
  providers: [BishopService]
})
export class BishopComponent implements OnInit {

  @Input() toolInfo: ToolInfo;
  @Output() public toolSelect = new EventEmitter<ToolData>();

  constructor(private BishopClass: BishopService) {}

  setServiceInfo() {
    this.BishopClass.tool     = this.toolInfo.tool;
    this.BishopClass.color    = this.toolInfo.color;
    this.BishopClass.position = this.toolInfo.position;
  }

  moveTool() {
    let possibleMoves = this.BishopClass.getPossibleMoves();
    this.toolSelect.emit({possibleMoves, toolInfo: this.toolInfo})
  }

  ngOnInit(): void {
    this.setServiceInfo();
  }

}
