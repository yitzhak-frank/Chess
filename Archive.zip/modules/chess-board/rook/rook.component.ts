import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { RookService } from 'src/app/services/rook.service';
import { ToolData, ToolInfo } from '../../../interfaces/tool-interface';

@Component({
  selector: 'app-rook',
  template: `<span (click)="moveTool()">{{toolInfo.tool}}</span>`,
  styles: [],
  providers: [RookService]
})
export class RookComponent implements OnInit {

  @Input() toolInfo: ToolInfo;
  @Output() public toolSelect = new EventEmitter<ToolData>();

  constructor(private RookClass: RookService) {}

  setServiceInfo() {
    this.RookClass.tool     = this.toolInfo.tool;
    this.RookClass.color    = this.toolInfo.color;
    this.RookClass.position = this.toolInfo.position;
  }

  moveTool() {
    let possibleMoves = this.RookClass.getPossibleMoves();
    this.toolSelect.emit({possibleMoves, toolInfo: this.toolInfo})
  }

  ngOnInit(): void {
    this.setServiceInfo();
  }

}
