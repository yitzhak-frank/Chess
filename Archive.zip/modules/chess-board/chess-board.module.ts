import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ChessTableComponent } from './chess-table/chess-table.component';
import { KingComponent } from './king/king.component';
import { QueenComponent } from './queen/queen.component';
import { RookComponent } from './rook/rook.component';
import { BishopComponent } from './bishop/bishop.component';
import { KnightComponent } from './knight/knight.component';
import { PawnComponent } from './pawn/pawn.component';
import { RookService } from 'src/app/services/rook.service';



@NgModule({
  declarations: [
    ChessTableComponent,
    KingComponent,
    QueenComponent,
    RookComponent,
    BishopComponent,
    KnightComponent,
    PawnComponent,
  ],
  exports: [ ChessTableComponent ],
  providers: [RookService],
  imports: [
    CommonModule
  ]
})
export class ChessBoardModule { }
