import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { PawnService } from 'src/app/services/pawn.service';
import { ToolData, ToolInfo } from '../../../interfaces/tool-interface';

@Component({
  selector: 'app-pawn',
  template: `<span (click)="moveTool()">{{toolInfo.tool}}</span>`,
  styles: [],
  providers: [PawnService]
})
export class PawnComponent implements OnInit {

  @Input() toolInfo: ToolInfo;
  @Output() public toolSelect = new EventEmitter<ToolData>();

  constructor(private PawnClass: PawnService) {}

  setServiceInfo() {
    this.PawnClass.tool     = this.toolInfo.tool;
    this.PawnClass.color    = this.toolInfo.color;
    this.PawnClass.position = this.toolInfo.position;
    this.PawnClass.isVirgin = this.toolInfo.isVirgin;
  }

  moveTool() {
    let possibleMoves = this.PawnClass.getPossibleMoves();
    this.toolSelect.emit({possibleMoves, toolInfo: this.toolInfo})
  }

  ngOnInit(): void {
    this.setServiceInfo();
  }

}
