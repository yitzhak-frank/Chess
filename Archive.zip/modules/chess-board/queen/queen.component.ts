import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { QueenService } from 'src/app/services/queen.service';
import { ToolData, ToolInfo } from '../../../interfaces/tool-interface';

@Component({
  selector: 'app-queen',
  template: `<span (click)="moveTool()">{{toolInfo.tool}}</span>`,
  styles: [],
  providers: [QueenService]
})
export class QueenComponent implements OnInit {

  @Input() toolInfo: ToolInfo;
  @Output() public toolSelect = new EventEmitter<ToolData>();

  constructor(private QueenClass: QueenService) {}

  setServiceInfo() {
    this.QueenClass.tool     = this.toolInfo.tool;
    this.QueenClass.color    = this.toolInfo.color;
    this.QueenClass.position = this.toolInfo.position;
  }

  moveTool() {
    let possibleMoves = this.QueenClass.getPossibleMoves();
    this.toolSelect.emit({possibleMoves, toolInfo: this.toolInfo})
  }

  ngOnInit(): void {
    this.setServiceInfo();
  }

}
